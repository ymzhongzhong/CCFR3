function pop = InitializePop(popSizeForGroups, Lbound, Ubound, D, groups)
    NP = max(popSizeForGroups);
    pop = nan(NP, D);
    for i = 1:numel(popSizeForGroups)
        NP = popSizeForGroups(i);
        dimIndexes_group = groups{i};
        D_group = numel(dimIndexes_group);
        pop(1:NP, dimIndexes_group) = repmat(Lbound(dimIndexes_group), NP, 1) + ...
            (repmat(Ubound(dimIndexes_group), NP, 1) - repmat(Lbound(dimIndexes_group), NP, 1)) .* rand(NP, D_group);
    end
end