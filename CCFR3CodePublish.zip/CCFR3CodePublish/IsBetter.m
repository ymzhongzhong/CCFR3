function isBetter001 = IsBetter(arg1, arg2, dimFlag, betterSign)
    isBetter = IsBetterObjLevel(arg1, arg2, betterSign);
    
    if size(arg1, dimFlag) > 1
        betterN = sum(isBetter == 1, dimFlag);
        equalN = sum(isBetter ==0, dimFlag);
        worseN = sum(isBetter == -1, dimFlag);
        isBetter001 = zeros(size(betterN));
        isBetter001(betterN + equalN == size(arg1, dimFlag) & betterN > 0) = 1;
        isBetter001(worseN + equalN == size(arg1, dimFlag) & worseN>0) = -1;
        isBetter001(equalN == size(arg1, dimFlag)) = -2; % equal
    else
        isBetter001 = isBetter;
    end
end

function isBetter = IsBetterObjLevel(arg1, arg2, betterSign)
    isBetter = sign(arg1 - arg2) * betterSign;
end