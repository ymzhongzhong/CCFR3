
% This program is implemented by Ming Yang (mingyang@cug.edu.cn). The
% referred paper: Ming Yang, Aimin Zhou, Xiaofen Lu, Zhihua Cai, Changhe Li
% and Jing Guan. CCFR3: A Cooperative Co-Evolution with Efficient Resource
% Allocation for Large-Scale Global Optimization, Expert Systems with
% Applications


%This file is the main file of the program. Please run this program as follows.
% %MyRun(functionNum, runIndexStart, runIndexEnd);
% % % functionNum: the serial number of a function in the problems, which is an integer
% % % runIndexStart and runIndexEnd: the values are integers. The program will run several times with different random seed.
% %Example: MyRun(1, 1,25);
% %For the example, the program will run 25 times on the CEC'2013 function f1.

function MyRun(varargin)
    warning off;
    global initial_flag; % the global flag used in test suite
    global runIndex;
    global maxFEs;
    
    benchmarkName = 'LargeScaleCEC2013Benchmark';
    D = 1000;
    maxFEs = 3e6;
    runsN = 25; % number of independent runs for each function, should be set to 25
    
    if isdeployed
        func_num = str2num(varargin{1});
        runIndexStart = str2num(varargin{2});
        runIndexEnd = str2num(varargin{3});
    else
        func_num = varargin{1};
        runIndexStart = varargin{2};
        runIndexEnd = varargin{3};
    end  
    decompositionMethod = 'ERDG';    
    
    global optimizer;
    optimizer = 'CMAES';
    
    AddPath(benchmarkName);
    Initialize(benchmarkName, D, func_num, [], decompositionMethod); 
    
    
    for runIndex = runIndexStart : runIndexEnd
        rand('seed', ceil(1 / (runsN +1)* runIndex * (2^32)));
        randn('seed', ceil(1 / (runsN +1)* runIndex * (2^32)));
        initial_flag = 0; % should set the flag to 0 for each run, each function
        CCFR3(); 
        OutputResults(benchmarkName, decompositionMethod, runIndex);
    end
end