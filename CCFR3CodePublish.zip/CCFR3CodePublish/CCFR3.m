function CCFR3()
    global groupIndexGlobal;
    global prob alg;
    global optimizer;
    global popSizeForGroups;
    
    groups = prob.groups;    
    groupN = size(groups,1);
    if strcmp(optimizer, 'CMAES')
        pop = [];
    else
        popSizeForGroups = SetPopSizeForGroups(groups);    
        pop = InitializePop(popSizeForGroups, prob.lb, prob.ub, prob.D, groups);
    end

    global evolState_group;
    for i = 1 : groupN
        evolState_group{i}.first = 1;
        evolState_group{i}.unChangeBestIndiGenN = 0;
        evolState_group{i}.lastbestIndi = nan(1, prob.D);
        evolState_group{i}.deltaFit = 0;
        evolState_group{i}.distToBestIndi = [];
    end
    

    deltaFit = zeros(groupN,1);

    while alg.isTerminate == 0
        [~, sortIndex] = sort(deltaFit, 'descend');
        for i= 1:groupN
            groupIndex = sortIndex(i);
            groupIndexGlobal = groupIndex;  
            if strcmp(optimizer, 'CMAES')
                deltaFit000 = Evolution_Group_CMAES(groupIndex, groups);
            end                 
            deltaFit(groupIndex) =deltaFit000;
            if alg.isTerminate==1
                break;
            end
        end
        logical001 = deltaFit == 0;
        if sum(~logical001) > 0
            deltaFit(logical001) = min(deltaFit(~logical001)) * 0.9;
        end
        for i= 1:groupN
            evolState_group{i}.deltaFit = deltaFit(i);
        end

         while (numel(deltaFit)==1 || min(deltaFit) ~= max(deltaFit))
            [~, groupIndexMax] = max(deltaFit);
            groupIndex = groupIndexMax(1);
            groupIndexGlobal = groupIndex;
            if strcmp(optimizer, 'CMAES')
                deltaFit000 = Evolution_Group_CMAES(groupIndex, groups);
            end
            deltaFit(groupIndex) =deltaFit000;
            if deltaFit(groupIndex) == 0 && any(deltaFit ~=0)
                deltaFit(groupIndex) = min(deltaFit(deltaFit~=0)) * 0.9;
            end
            evolState_group{groupIndex}.deltaFit = deltaFit(groupIndex);
            if alg.isTerminate==1
                break;
            end
         end
    end
end



function [deltaFit001] = Evolution_Group_CMAES(groupIndex, groups)
    dimIndexGroup = groups{groupIndex};
    [~, deltaFit001] = CMAES_group(dimIndexGroup);
end
