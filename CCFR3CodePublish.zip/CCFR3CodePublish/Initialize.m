function Initialize(benchmarkName, D, func_num, NP, decompositionMethod) 
    global prob alg;
    global maxFEs;
    
    [lb001, ub001]=SetProbBound(benchmarkName,func_num);
    if strcmp(benchmarkName,'LargeScaleCEC2013Benchmark')==1 && ismember(func_num, [13,14])
        D = 905;
    end
    
    
    groupFilePath = strcat('./',benchmarkName,'/GroupResult/', decompositionMethod);
    groupFile = strcat(groupFilePath, '/f', num2str(func_num), '_groups.mat');
    load(groupFile, '-mat', 'groups', 'fEvalNum');    

    prob.betterSign = -1; % -1 for minimization, 1 for maximization
    prob.D = D;    
    prob.fhd = str2func('benchmark_func'); %fitness function
    prob.fNum = func_num;
    prob.objN = 1; % 1 for single-objective optimization
    prob.lb = lb001*ones(1,D); prob.ub = ub001*ones(1,D);
    prob.groups = groups;
    
    alg.outputValues = [];
    alg.fEvalNum = fEvalNum;
    alg.fEvalNumIntial = fEvalNum;
    alg.bestGlobal = [];
    alg.NP = NP;    
    alg.Max_FEs = maxFEs;
    alg.mustOutputPoints = [];    
    alg.isTerminate = 0;    
end