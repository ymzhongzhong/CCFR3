function popSizeForGroups = SetPopSizeForGroups(groups)
    groupN = size(groups,1);
    popSizeForGroups = zeros(groupN, 1);
    for i = 1:groupN
        popSizeForGroups(i) = size(groups{i}, 2) + 25;  
    end
end