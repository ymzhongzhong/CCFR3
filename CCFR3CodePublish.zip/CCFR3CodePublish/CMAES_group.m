function [isStagnate, deltaFitFinal] = CMAES_group(groupDimIndex)
    global alg prob;
    global groupIndexGlobal;
    global evolState_group;
    
    
    groupDimIndexN = numel(groupDimIndex);
    lbvec = prob.lb(groupDimIndex);
    ubvec = prob.ub(groupDimIndex);
    lbvec = lbvec'; ubvec = ubvec';

if evolState_group{groupIndexGlobal}.first == 1    
    subxmean = lbvec+(ubvec-lbvec)/2;    % objective variables initial point
    subsigma = 0.3*(ubvec-lbvec);          % coordinate wise standard deviation (step size)
    
    % Strategy parameter setting: Selection
    sublambda = 4+floor(3*log(groupDimIndexN));  % population size, offspring number
    submu = sublambda /2;                    % number of parents/points for recombination
    subweights = log(submu+1/2)-log(1:submu)'; % muXone array for weighted recombination
    submu= floor(submu);
    subweights = subweights/sum(subweights);     % normalize recombination weights array
    submueff = sum(subweights)^2/sum(subweights.^2); % variance-effectiveness of sum w_i x_i

    % Strategy parameter setting: Adaptation
    subcc = (4 + submueff/groupDimIndexN) / (groupDimIndexN+ 4 + 2*submueff/groupDimIndexN); % time constant for cumulation for C
    subcs = (submueff+2) / (groupDimIndexN+submueff+5);  % t-const for cumulation for sigma control
    subc1 = 2 / ((groupDimIndexN+1.3)^2+submueff);    % learning rate for rank-one update of C
    subcmu = min(1-subc1, 2 * (submueff-2+1/submueff) / ((groupDimIndexN+2)^2+submueff));  % and for rank-mu update
    subdamps= 1 + 2*max(0, sqrt((submueff-1)/(groupDimIndexN+1))-1) + subcs; % damping for sigma 
                                                      % usually close to 1

    % Initialize dynamic (internal) strategy parameters and constants
    subpc = zeros(groupDimIndexN,1);
    subps = zeros(groupDimIndexN,1);
    subB = eye(groupDimIndexN,groupDimIndexN);
    subD = ones(groupDimIndexN,1);
    subC = subB * diag(subD.^2) * subB';
    subinvsqrtC = subB * diag(subD.^-1) * subB';
    subeigeneval = 0;
    subchiN = groupDimIndexN^0.5*(1-1/(4*groupDimIndexN)+1/(21*groupDimIndexN^2));
    
    iterationNum = 0;
    subcounteval = 0;
else
    sublambda = evolState_group{groupIndexGlobal}.sublambda;   
    submu = evolState_group{groupIndexGlobal}.submu;       
    subweights = evolState_group{groupIndexGlobal}.subweights;  
    submueff = evolState_group{groupIndexGlobal}.submueff;    

    subcc = evolState_group{groupIndexGlobal}.subcc;       
    subcs = evolState_group{groupIndexGlobal}.subcs;       
    subc1 = evolState_group{groupIndexGlobal}.subc1;       
    subcmu = evolState_group{groupIndexGlobal}.subcmu;      
    subdamps = evolState_group{groupIndexGlobal}.subdamps;    
    subartmp = evolState_group{groupIndexGlobal}.subartmp;
    subpc = evolState_group{groupIndexGlobal}.subpc;       
    subps = evolState_group{groupIndexGlobal}.subps;       
    subB = evolState_group{groupIndexGlobal}.subB;        
    subD = evolState_group{groupIndexGlobal}.subD;        
    subC = evolState_group{groupIndexGlobal}.subC;        
    subinvsqrtC = evolState_group{groupIndexGlobal}.subinvsqrtC; 
    subeigeneval = evolState_group{groupIndexGlobal}.subeigeneval;
    subchiN = evolState_group{groupIndexGlobal}.subchiN;    
    
    subxmean = evolState_group{groupIndexGlobal}.subxmean;    
    subsigma = evolState_group{groupIndexGlobal}.subsigma;    
    
    iterationNum = evolState_group{groupIndexGlobal}.iterationNum;
    subcounteval = evolState_group{groupIndexGlobal}.subcounteval;
end

arfitness = nan(sublambda, 1);
if isempty(alg.bestGlobal)
    randIndi = prob.lb + (prob.ub-prob.lb) .* rand(1, prob.D);
    arx =  repmat(randIndi', 1, sublambda);   
    EvaluateFit(prob.fhd, randIndi);
else
    arx = repmat(alg.bestGlobal.x', 1, sublambda);
end
bestIndiGlobalBefore001 = alg.bestGlobal.x;
bestIndiGlobalBefore002 = alg.bestGlobal.x;
bestFitGlobalBefore001 = alg.bestGlobal.f;
bestFitGlobalBeforeEvol = alg.bestGlobal.f;
fEvalNumBeforeEvol = alg.fEvalNum;
fEvalNumBefore001 = alg.fEvalNum;
evolState_group{groupIndexGlobal}.unChangeBestIndiGenN = 0;
deltaFitFinal = 0;
isStagnate = 0;
stdDeltaFit =0; deltaFitSet=[];
evolState_group{groupIndexGlobal}.distToBestIndi = [];

 
while alg.isTerminate == 0
    iterationNum = iterationNum + 1;
    
    % Generate and evaluate lambda offspring
    for k=1:sublambda
        mysigma = subsigma .* (subB * (subD .* randn(groupDimIndexN,1)));
        logicalTemp001 = abs(mysigma) >(ubvec-lbvec);
        if sum(logicalTemp001) > 0
            mysigma(logicalTemp001) = ((ubvec(logicalTemp001)-lbvec(logicalTemp001))) .* randn(sum(logicalTemp001),1);
        end
        tempX = subxmean + mysigma;
        logicalTemp = (tempX < lbvec | tempX > ubvec);
        while any(logicalTemp)
            mysigma(logicalTemp) =  subsigma(logicalTemp) .* (subB(logicalTemp, logicalTemp) * (subD(logicalTemp) .* randn(sum(logicalTemp),1))); 
            logicalTemp001 = abs(mysigma) > (ubvec-lbvec);
            if sum(logicalTemp001) > 0
                mysigma(logicalTemp & logicalTemp001) = ((ubvec(logicalTemp & logicalTemp001)-lbvec(logicalTemp & logicalTemp001))) .* randn(sum(logicalTemp & logicalTemp001),1);
            end
            tempX(logicalTemp) = subxmean(logicalTemp) + mysigma(logicalTemp);
            logicalTemp = (tempX < lbvec | tempX > ubvec);
        end
        
        arx(groupDimIndex,k) = tempX; % this is only for grouping{i}
        arfitness(k) = EvaluateFit(prob.fhd, arx(:,k)');

        subcounteval = subcounteval +1;
    end
    % Sort by fitness and compute weighted mean into xmean
    [arfitness, arindex] = sort(arfitness);  % minimization
    subxold = subxmean;
    subxmean = arx(groupDimIndex,arindex(1:submu)) * subweights;  % recombination, new mean value
    % Cumulation: Update evolution paths
    subps = (1-subcs) * subps ... 
          + sqrt(subcs*(2-subcs)*submueff) * subinvsqrtC * ((subxmean-subxold) ./ subsigma); 
    subhsig = sum(subps.^2)/(1-(1-subcs)^(2*subcounteval/sublambda))/groupDimIndexN < 2 + 4/(groupDimIndexN+1);
    subpc = (1-subcc) * subpc ...
          + subhsig * sqrt(subcc*(2-subcc)*submueff) * ((subxmean -subxold) ./ subsigma); 
      
     % Adapt covariance matrix C
    subartmp = repmat(1./subsigma, 1, submu) .* ((arx(groupDimIndex,arindex(1:submu)) - repmat(subxold,1,submu)));  % mu difference vectors
    subC = (1-subc1-subcmu) * subC ...                   % regard old matrix  
         + subc1 * (subpc * subpc' ...                % plus rank one update
                 + (1-subhsig) * subcc*(2-subcc) * subC) ... % minor correction if hsig==0
         + subcmu * subartmp * diag(subweights) * subartmp'; % plus rank mu update 

    % Adapt step size sigma
    subsigma = subsigma * exp((subcs/subdamps)*(norm(subps)/subchiN - 1)); 
    tempLogical = abs(subsigma) > (ubvec-lbvec); 
    if any(tempLogical)
        subsigma(tempLogical) =  (ubvec(tempLogical) - lbvec(tempLogical));
    end
    tempLogical = abs(subsigma) <realmin;
    if any(tempLogical)
        subsigma(tempLogical) =  realmin;
    end
    
    % Update B and D from C
    if subcounteval - subeigeneval > sublambda/(subc1+subcmu)/groupDimIndexN/10  % to achieve O(N^2)
      subeigeneval = subcounteval;
      subC = triu(subC) + triu(subC,1)'; % enforce symmetry
      if ~(any(any(isnan(subC))) || any(any(isinf(subC))))
        [subB,subD] = eig(subC);           % eigen decomposition, B==normalized eigenvectors
        subD = abs(subD); %%%%%%%%?????????
        subD = sqrt(diag(subD));        % D contains standard deviations now
        subD(subD < realmin) = realmin;
        subD(subD > realmax) = realmax;
        subinvsqrtC = subB * diag(subD.^-1) * subB';
      end
    end 

    fprintf('%d\t %d\t %d\t %.5e\n', ...
            prob.fNum, alg.fEvalNum, groupIndexGlobal, alg.bestGlobal.f); %%% test use %%%%%%%%%%%%%%%%

    
    stopEvol = 0;
    if ~isempty(bestIndiGlobalBefore001)
        if sum(bestIndiGlobalBefore001(groupDimIndex) ~= alg.bestGlobal.x(groupDimIndex)) == numel(groupDimIndex) 
            deltaFit001 = abs(bestFitGlobalBefore001 - alg.bestGlobal.f)/(alg.fEvalNum-fEvalNumBefore001);
            deltaFitSet = [deltaFitSet, deltaFit001];
            stdDeltaFit001 = std(deltaFitSet,1);
             if numel(deltaFitSet)>2    %~isempty(stdDeltaFit)
                if stdDeltaFit001 < stdDeltaFit %&& meanDeltaFit001 < meanDeltaFit
                    stopEvol = 1;
                end
             end
            stdDeltaFit = stdDeltaFit001;
            bestIndiGlobalBefore001 = alg.bestGlobal.x;
            bestFitGlobalBefore001 = alg.bestGlobal.f;
            fEvalNumBefore001 = alg.fEvalNum;
        end   
    end
    
    stopEvol001 = 0; isStagnant = 0;
    bestIndiIndex = arindex(1);
    pop = arx';
    if sum(bestIndiGlobalBefore002(groupDimIndex) == alg.bestGlobal.x(groupDimIndex)) == numel(groupDimIndex)                 
        if isempty(evolState_group{groupIndexGlobal}.distToBestIndi) 
            distToBestIndi = sum(sum(abs(pop(:, groupDimIndex) - repmat(pop(bestIndiIndex, groupDimIndex), size(pop,1), 1)), 2)) / size(pop,1);   
            evolState_group{groupIndexGlobal}.distToBestIndi = distToBestIndi;
        end
        evolState_group{groupIndexGlobal}.unChangeBestIndiGenN = evolState_group{groupIndexGlobal}.unChangeBestIndiGenN + 1;
        UN001 = sublambda;
        if evolState_group{groupIndexGlobal}.unChangeBestIndiGenN >= UN001
            evolState_group{groupIndexGlobal}.unChangeBestIndiGenN =  UN001;
             if ~isempty(evolState_group{groupIndexGlobal}.distToBestIndi)
                 distToBestIndi = sum(sum(abs(pop(:, groupDimIndex) - repmat(pop(bestIndiIndex, groupDimIndex), size(pop,1), 1)), 2)) / size(pop,1);   
                 if distToBestIndi <= evolState_group{groupIndexGlobal}.distToBestIndi
                    stopEvol001 = 1;
                    if distToBestIndi == evolState_group{groupIndexGlobal}.distToBestIndi
                        isStagnant = 1;
                     end
                 end                 
            end
        end
    else            
        evolState_group{groupIndexGlobal}.unChangeBestIndiGenN = 0;
        evolState_group{groupIndexGlobal}.distToBestIndi = [];
    end
    bestIndiGlobalBefore002 = alg.bestGlobal.x;

    if stopEvol == 1 || stopEvol001 == 1
       if stopEvol001 == 1
           if isStagnant == 1
               deltaFitFinal = 0;
           else
                deltaFitFinal = abs(bestFitGlobalBeforeEvol - alg.bestGlobal.f) / (alg.fEvalNum - fEvalNumBeforeEvol);
                deltaFitFinal = 0.5 * evolState_group{groupIndexGlobal}.deltaFit + 0.5*deltaFitFinal; 
           end
       end
       if stopEvol == 1
            deltaFitFinal = abs(bestFitGlobalBeforeEvol - alg.bestGlobal.f) / (alg.fEvalNum - fEvalNumBeforeEvol);
       end
       
       break;
    end
end


evolState_group{groupIndexGlobal}.first = 0;

evolState_group{groupIndexGlobal}.sublambda = sublambda;   
evolState_group{groupIndexGlobal}.submu = submu;       
evolState_group{groupIndexGlobal}.subweights = subweights;  
evolState_group{groupIndexGlobal}.submueff = submueff;    

evolState_group{groupIndexGlobal}.subcc = subcc;       
evolState_group{groupIndexGlobal}.subcs = subcs;       
evolState_group{groupIndexGlobal}.subc1= subc1;       
evolState_group{groupIndexGlobal}.subcmu = subcmu;      
evolState_group{groupIndexGlobal}.subdamps = subdamps;    
evolState_group{groupIndexGlobal}.subartmp = subartmp;

evolState_group{groupIndexGlobal}.subpc = subpc;       
evolState_group{groupIndexGlobal}.subps = subps;       
evolState_group{groupIndexGlobal}.subB = subB;        
evolState_group{groupIndexGlobal}.subD = subD;        
evolState_group{groupIndexGlobal}.subC = subC;        
evolState_group{groupIndexGlobal}.subinvsqrtC = subinvsqrtC; 
evolState_group{groupIndexGlobal}.subeigeneval = subeigeneval;
evolState_group{groupIndexGlobal}.subchiN = subchiN;    

evolState_group{groupIndexGlobal}.subxmean = subxmean;    
evolState_group{groupIndexGlobal}.subsigma = subsigma;    

evolState_group{groupIndexGlobal}.iterationNum = iterationNum;
evolState_group{groupIndexGlobal}.subcounteval = subcounteval;
end