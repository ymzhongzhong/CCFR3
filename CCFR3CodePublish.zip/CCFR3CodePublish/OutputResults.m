function OutputResults(benchmarkName, decomposition, runIndex)
    global alg prob;
    global optimizer;
    outputFileDir = strcat('./',benchmarkName, '/OptResult/CCFR3_', decomposition, '_', optimizer, '/');
    if ~exist(outputFileDir, 'dir')
        mkdir(outputFileDir);
    end
    outputFileName = strcat(outputFileDir, '/f', num2str(prob.fNum), '_run', num2str(runIndex), '.mresult');
    fid = fopen(outputFileName, 'w');
    fprintf(fid, strcat('%d', repmat('\t%.10E', 1, prob.objN), '\n'), alg.outputValues');    
    fclose(fid);
end